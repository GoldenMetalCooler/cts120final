﻿CST-120 Milestone 7 - Final Website
Vijesh Agarwal

Overview
- Personal website with six pages.
- Built with HTML, CSS, and JavaScript.
- Uses Bootstrap 5.3.3 for layout and components, jQuery 3.7.1 for interactivity, and Chart.js 4.4.7 for the chart.
- All libraries are stored locally in the project instead of using a CDN.

How to open locally
1. Unzip the folder and keep the files in their current locations.
2. Open about.html (the home page) and use the navigation menu to move through the site.
3. No install or build steps are required.

Pages
- about.html - Home/About Me
- hobbies.html - Hobbies, table, and chart
- photos.html - Photo gallery
- projects.html - Project cards and filters
- resources.html - CSS guides and suggestion form
- contact.html - Contact form and Email Updates form

Forms
1. Contact form (contact.html, id contact-form)
   - Bootstrap form with validation states
   - Required: name, email, topic, and message
   - Client-side validation is used (js/contact.js)
   - No data is sent anywhere

2. Email Updates form (contact.html, id email-form)
   - Standard HTML form (method="post") that posts to the W3Schools test responder
   - Fields: fname, email, frequency, consent, subscribe. Required: email and the consent checkbox
   - Works with JavaScript turned off
   - Intended for live testing only
   - Use made-up data when testing

3. Suggest a Resource form (resources.html, id suggest-form)
   - Bootstrap form classes with JavaScript validation (js/resources.js)
   - Validates input and shows suggestions on the page
   - No data is sent anywhere

Where Bootstrap and other libraries are used
- Bootstrap 5.3.3 (MIT): navbar, grid, cards, buttons, and form classes on every page; modal on projects.html; toast on contact.html; collapse menu on every page
- jQuery 3.7.1 (MIT): FAQ on about.html (js/about.js), contact form behavior (js/contact.js), project filters (js/projects.js)
- Chart.js 4.4.7 (MIT): the chart on hobbies.html (js/hobbies-chart.js)
- Lexend font (SIL Open Font License): self-hosted in fonts/
- Bootstrap theme overrides are in css/theme.css; shared styles are in css/styles.css

Libraries and file layout
- Bootstrap 5.3.3: local CSS and JS files
- jQuery 3.7.1: local JS file
- Chart.js 4.4.7: local JS file
- Lexend font: local font files
- Project folders are kept in this layout so relative links keep working:
  - root pages
  - css/
  - js/
  - images/
  - fonts/
  - media/
  - ui/

Accessibility and responsiveness
- Works on phone, tablet, and desktop layouts
- Mobile menu collapses into a burger button
- Keyboard focus states are visible
- Reduced-motion support is included
- ARIA attributes are added for FAQ toggles, filters, modal, toast, and form feedback
- High contrast and alt text are used where needed

Privacy and production considerations
- Use HTTPS in production
- Validate form data on the server as well as in the browser
- Collect only the information that is needed
- Store data securely and use double opt-in for email signups
- Include an unsubscribe link and delete data when it is no longer needed

Testing notes
- Empty contact form: validation errors appear and focus moves to the first invalid field
- Valid contact form: success toast appears
- Email Updates form: fill it in online and submit to confirm the form posts name/value pairs to the W3Schools test page
- Suggest a Resource form: empty submit shows errors; valid submit adds the suggestion to the list

Files refactored in Milestone 7
- contact.html: added the Email Updates form and comments for both forms
- resources.html: added comments for the Suggest form
- css/styles.css: form rules no longer stretch radio buttons and checkboxes
- js/resources.js: removed unused submit code and commented the validation rules
- All HTML, CSS, and JS files: added top-line comments (purpose, third-party libraries, licenses)
- Fixed a stray quote typo in the navigation link markup

Remaining issues
- Contact and suggestion data is not saved (on purpose)
- The Email Updates form needs internet and leaves the site; nothing is really subscribed
- Browsers without <dialog> support show the gallery without the enlarge feature
- The music video file is large and may load slowly

Important note
- The site is a static HTML/CSS/JS project, so there are no build steps or package installs.
- The folder structure and relative file paths should stay unchanged to avoid broken links.