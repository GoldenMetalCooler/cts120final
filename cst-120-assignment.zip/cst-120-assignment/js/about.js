/* about.js - FAQ interactions (slide open/closed, "Open all answers" toggle).
   Third-party: jQuery 3.7.1 (MIT, local copy in js/vendor). */
$(function () {
  "use strict";

  // One delegated handler covers all FAQ buttons.
  var $faq = $("#faq");

  $faq.on("click", ".faq__toggle", function () {
    var $button = $(this);
    var $answer = $("#" + $button.attr("aria-controls"));
    var willOpen = $button.attr("aria-expanded") === "false";

    if (willOpen) {
      $answer.prop("hidden", false).attr("aria-hidden", "false").stop(true, true).slideDown(200);
      $button.attr("aria-expanded", "true").toggleClass("is-open", true);
    } else {
      $answer.attr("aria-hidden", "true").stop(true, true).slideUp(200, function () { $(this).prop("hidden", true); });
      $button.attr("aria-expanded", "false").toggleClass("is-open", false);
    }
    $button.css("--mark", willOpen ? "'\\2212'" : "'+'");
  });

  $("#faq-toggle-all").on("click", function () {
    var $all = $(this);
    var open = $all.attr("aria-pressed") !== "true";
    $faq.find(".faq__toggle").each(function () {
      var $b = $(this);
      var isOpen = $b.attr("aria-expanded") === "true";
      if (isOpen !== open) { $b.trigger("click"); }
    });
    $all.attr("aria-pressed", String(open)).text(open ? "Close all answers" : "Open all answers");
  });
});
