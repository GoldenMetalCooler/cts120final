/* contact.js - Contact form: character counter, conditional "Other" field, validation, and confirmation toast.
   Third-party: jQuery 3.7.1 and Bootstrap 5.3.3 (Toast), both MIT, local copies in js/vendor. */$(function () {
  "use strict";
  var $form = $("#contact-form");
  var MAX = 300;

  // The counter is described by the message field, but is not a live region.
  $("#ct-message").on("input", function () {
    var n = this.value.length;
    $("#ct-count").text(n + " / " + MAX).toggleClass("text-warning", n > MAX - 30);
  });

  // Keep the conditional field's visibility and ARIA state in sync.
  $("#ct-topic").on("change", function () {
    var isOther = $(this).val() === "other";
    $(this).attr("aria-expanded", String(isOther));
    var $row = $("#ct-other-row");
    if (isOther) { $row.prop("hidden", false).hide().slideDown(150); }
    else { $row.slideUp(150, function () { $(this).prop("hidden", true); }); $("#ct-other").val(""); }
    $("#ct-other").prop("required", isOther);
  });

  // Validate before showing the confirmation.
  $form.on("submit", function (event) {
    event.preventDefault();
    if (!this.checkValidity()) {
      $form.addClass("was-validated");
      var $first = $form.find(":invalid").first();
      $first.trigger("focus");
      window.SiteUtils.announce("The form has errors. Check " + ($first.attr("data-label") || "the highlighted field") + ".");
      return;
    }
    bootstrap.Toast.getOrCreateInstance(document.getElementById("contact-toast")).show();
    this.reset();
    $form.removeClass("was-validated");
    $("#ct-count").text("0 / " + MAX).removeClass("text-warning");
    $("#ct-other-row").prop("hidden", true);
    $("#ct-topic").attr("aria-expanded", "false");
  });
});
