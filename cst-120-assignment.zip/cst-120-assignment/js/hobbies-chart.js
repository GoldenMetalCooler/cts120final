/* hobbies-chart.js - Draws the weekly hours chart from the hobby table.
   Third-party: Chart.js 4.4.7 (MIT, local copy in js/vendor). */
   document.addEventListener("DOMContentLoaded", function () {
  "use strict";
  var canvas = document.getElementById("hours-chart");
  var rows = document.querySelectorAll("#hobby-table tbody tr");
  if (!canvas || rows.length === 0 || typeof Chart === "undefined") { return; }

  // Use the higher number for ranges, matching hobbies.js.
  function hoursFrom(text) {
    var parts = text.split("-");
    var last = parseFloat(parts[parts.length - 1]);
    return isNaN(last) ? 0 : last;
  }

  var labels = [], hours = [];
  rows.forEach(function (row) {
    labels.push(row.cells[0].textContent.trim());
    hours.push(hoursFrom(row.cells[2].textContent));
  });

  // Respect reduced-motion preferences.
  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  new Chart(canvas, {
    type: "bar",
    data: { labels: labels, datasets: [{ label: "Hours per week (upper estimate)", data: hours, backgroundColor: "#ffd479", borderColor: "#ffffff", borderWidth: 1 }] },
    options: {
      indexAxis: "y",
      responsive: true,
      maintainAspectRatio: false,
      animation: reduceMotion ? false : { duration: 600 },
      plugins: { legend: { display: false }, tooltip: { enabled: true } },
      scales: {
        x: { beginAtZero: true, title: { display: true, text: "Hours per week", color: "#f0f0f0" }, ticks: { color: "#f0f0f0" }, grid: { color: "#6b3a3a" } },
        y: { ticks: { color: "#f0f0f0", font: { size: 14 } }, grid: { display: false } }
      }
    }
  });
  window.SiteUtils.announce("Chart of weekly hobby hours loaded. The table above has the same numbers.");
});
