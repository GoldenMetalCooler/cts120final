/* hobbies.js - Highlights hobbies by weekly hours. Third-party: none (my own code). */
document.addEventListener("DOMContentLoaded", function () {
  "use strict";

  var button = document.getElementById("highlight-btn");
  var rows = document.querySelectorAll("#hobby-table tbody tr");
  if (!button || rows.length === 0) { return; }

  // Use the higher number for ranges such as "3-6".
  function hoursFrom(text) {
    var parts = text.split("-");
    var last = parseFloat(parts[parts.length - 1]);
    return isNaN(last) ? 0 : last;
  }

  // Toggle row highlights and announce the result.
  button.addEventListener("click", function () {
    var turningOn = button.getAttribute("aria-pressed") !== "true";
    var changed = 0;

    for (var row of rows) {
      var hours = hoursFrom(row.cells[2].textContent);
      row.classList.remove("hobby--heavy", "hobby--medium", "hobby--light");
      row.querySelectorAll(".hobby-badge").forEach(function (old) { old.remove(); });
      if (!turningOn) { continue; }

      var level, label;
      if (hours >= 10)      { level = "heavy";  label = "Most time"; }
      else if (hours >= 5)  { level = "medium"; label = "Regular"; }
      else                  { level = "light";  label = "Occasional"; }

      row.classList.add("hobby--" + level);
      var badge = document.createElement("span");
      badge.className = "hobby-badge";
      badge.textContent = label;
      row.cells[0].appendChild(badge);
      changed++;
    }

    switch (turningOn) {
      case true:
        button.textContent = "Remove highlights";
        window.SiteUtils.announce("Highlighted " + changed + " hobbies by weekly hours.");
        break;
      default:
        button.textContent = "Highlight my most-played hobbies";
        window.SiteUtils.announce("Highlights removed.");
    }
    button.setAttribute("aria-pressed", String(turningOn));
  });
});
