/* photos.js - Opens photos in a native dialog and returns focus on close. Third-party: none (my own code). */
document.addEventListener("DOMContentLoaded", function () {

  var gallery = document.querySelector(".gallery");
  var dialog = document.getElementById("photo-dialog");
  var dialogImg = document.getElementById("photo-dialog-img");
  var dialogTitle = document.getElementById("photo-dialog-title");
  var dialogText = document.getElementById("photo-dialog-text");
  var closeBtn = document.getElementById("photo-dialog-close");
  if (!gallery || !dialog || typeof dialog.showModal !== "function") { return; }

  var lastTrigger = null;

  // One delegated listener handles every photo button.
  gallery.addEventListener("click", function (event) {
    var trigger = event.target.closest(".gallery__open");
    if (!trigger || !gallery.contains(trigger)) { return; }

    var img = trigger.querySelector("img");
    var caption = trigger.closest(".gallery__item").querySelector(".gallery__caption");
    dialogImg.src = img.currentSrc || img.src;
    dialogImg.alt = img.alt;
    dialogTitle.textContent = caption.querySelector("strong").textContent;
    dialogText.textContent = caption.querySelector(".gallery__desc").textContent;

    lastTrigger = trigger;
    trigger.setAttribute("aria-expanded", "true");
    dialog.showModal();
    closeBtn.focus();
  });

  closeBtn.addEventListener("click", function () { dialog.close(); });

  dialog.addEventListener("click", function (event) {
    if (event.target === dialog) { dialog.close(); }
  });

  // Restore focus to the photo button after closing.
  dialog.addEventListener("close", function () {
    if (lastTrigger) {
      lastTrigger.setAttribute("aria-expanded", "false");
      lastTrigger.focus();
    }
  });
});
