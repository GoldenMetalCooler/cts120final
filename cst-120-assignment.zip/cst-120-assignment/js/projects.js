/* projects.js - Filters project cards and fills the details modal.
   Third-party: jQuery 3.7.1 and Bootstrap 5.3.3 (modal events), both MIT, local copies in js/vendor. */
$(function () {
  "use strict";
  var $buttons = $(".filter-btn");
  var $cols = $(".project-col");

  $buttons.on("click", function () {
    var $btn = $(this);
    var filter = $btn.data("filter");
    $buttons.attr("aria-pressed", "false");
    $btn.attr("aria-pressed", "true");

    var $match = filter === "all" ? $cols : $cols.filter('[data-category="' + filter + '"]');
    var $rest = $cols.not($match);
    $rest.stop(true, true).fadeOut(150, function () { $(this).prop("hidden", true); });
    $match.prop("hidden", false).stop(true, true).hide().fadeIn(200);
    $buttons.removeClass("active"); $btn.addClass("active");
    $("#project-count").text($match.length + (filter === "all" ? " projects shown" : " project(s) in " + $btn.text()));
    window.SiteUtils.announce($match.length + " projects showing.");
  });

  // Use Bootstrap's native event to populate the modal.
  var modal = document.getElementById("project-modal");
  modal.addEventListener("show.bs.modal", function (event) {
    var $trigger = $(event.relatedTarget);
    $("#project-modal-title").text($trigger.data("title"));
    $("#project-modal-body").text($trigger.data("body"));
    $("#project-modal-tools").text($trigger.data("tools"));
  });
});
