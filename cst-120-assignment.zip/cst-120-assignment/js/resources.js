/* resources.js - Validates and displays resource suggestions locally (nothing is sent or stored).
   Third-party: none in this file (my own code); Bootstrap only styles the page. */
document.addEventListener("DOMContentLoaded", function () {
  "use strict";

  var form = document.getElementById("suggest-form");
  var list = document.getElementById("suggestion-list");
  var category = document.getElementById("sg-category");
  var hint = document.getElementById("sg-category-hint");
  var emptyNote = document.getElementById("suggestion-empty");
  if (!form || !list) { return; }

  category.addEventListener("change", function () {
    switch (category.value) {
      case "cascade":    hint.textContent = "Guides about how browsers choose which style wins."; break;
      case "layout":     hint.textContent = "Flexbox, Grid, and responsive design tutorials."; break;
      case "javascript": hint.textContent = "Events, forms, and DOM tutorials."; break;
      case "access":     hint.textContent = "Accessibility and ARIA guides."; break;
      default:           hint.textContent = "Pick the closest fit.";
    }
  });

  // Keep each field's error and ARIA state in sync.
  function setError(field, message) {
    var box = document.getElementById(field.id + "-error");
    if (message) {
      field.setAttribute("aria-invalid", "true");
      field.setAttribute("aria-describedby", box.id);
      box.textContent = message;
    } else {
      field.removeAttribute("aria-invalid");
      field.removeAttribute("aria-describedby");
      box.textContent = "";
    }
  }

  function validateField(field) {
    var value = field.value.trim();
    if (value === "") { return "Please fill in this field."; }
    if (field.type === "url") {
      try {
        var parsed = new URL(value);
        if (parsed.protocol !== "https:" && parsed.protocol !== "http:") { return "Use a web address that starts with http or https."; }
      } catch (e) { return "Enter a full web address, like https://example.com."; }
    }
    if (field.tagName === "TEXTAREA" && value.length < 15) { return "Please write at least 15 characters about why it helps."; }
    return "";
  }

  // focusout bubbles, so one listener can validate every required field.
  form.addEventListener("focusout", function (event) {
    if (event.target.matches("[required]")) { setError(event.target, validateField(event.target)); }
  });

  form.addEventListener("submit", function (event) {
    event.preventDefault();

    var fields = form.querySelectorAll("[required]");
    var firstBad = null;
    var errorCount = 0;

    fields.forEach(function (field) {
      var message = validateField(field);
      setError(field, message);
      if (message) {
        errorCount++;
        if (!firstBad) { firstBad = field; }
      }
    });

    if (errorCount > 0) {
      window.SiteUtils.announce(errorCount + (errorCount === 1 ? " field needs" : " fields need") + " attention.");
      firstBad.focus();
      return;
    }

    var data = {
      name: window.SiteUtils.toText(form.elements["sg-name"].value),
      title: window.SiteUtils.toText(form.elements["sg-title"].value),
      url: form.elements["sg-url"].value.trim(),
      category: category.options[category.selectedIndex].text,
      why: window.SiteUtils.toText(form.elements["sg-why"].value)
    };

    addSuggestion(data);
  });

  function addSuggestion(data) {
    var item = document.createElement("li");
    item.className = "suggestion";

    var text = document.createElement("div");
    var heading = document.createElement("strong");
    heading.textContent = data.title;
    var meta = document.createElement("p");
    meta.textContent = data.category + " - suggested by " + data.name + ". " + data.why;
    var link = document.createElement("a");
    link.href = data.url;
    link.textContent = "Open the suggestion";
    link.rel = "noopener noreferrer";
    link.target = "_blank";
    text.append(heading, meta, link);

    var remove = document.createElement("button");
    remove.type = "button";
    remove.className = "button button--small suggestion__remove";
    remove.textContent = "Remove";
    remove.setAttribute("aria-label", "Remove suggestion: " + data.title);

    item.append(text, remove);
    list.appendChild(item);
    if (emptyNote) { emptyNote.hidden = true; }

    form.reset();
    hint.textContent = "Pick the closest fit.";
    window.SiteUtils.announce("Thanks! Your suggestion was added to the list below.");
    remove.focus();   // Focus moves to the new item so the visitor lands on the result.
  }

  // Delegate clicks so dynamically added suggestions can be removed.
  list.addEventListener("click", function (event) {
    var btn = event.target.closest(".suggestion__remove");
    if (!btn) { return; }
    var item = btn.closest(".suggestion");
    var next = item.nextElementSibling || item.previousElementSibling;
    item.remove();
    if (list.children.length === 0 && emptyNote) { emptyNote.hidden = false; }
    // Keep focus on a remaining suggestion or return it to the form.
    (next ? next.querySelector(".suggestion__remove") : document.getElementById("sg-name")).focus();
    window.SiteUtils.announce("Suggestion removed.");
  });
});
