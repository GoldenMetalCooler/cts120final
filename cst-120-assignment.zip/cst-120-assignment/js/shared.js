/* shared.js - Helpers used by page scripts (announce to screen readers, expand/collapse, strip angle brackets).
   Third-party: none (my own code). */
(function () {
  "use strict";

  window.SiteUtils = {

    // Update visibility and related ARIA attributes.
    setExpanded: function (trigger, panel, isOpen) {
      trigger.setAttribute("aria-expanded", String(isOpen));
      panel.hidden = !isOpen;
      panel.setAttribute("aria-hidden", String(!isOpen));
    },

    // Announce a message without moving focus.
    announce: function (message) {
      var region = document.getElementById("status-region");
      if (!region) { return; }
      region.textContent = "";
      window.setTimeout(function () { region.textContent = message; }, 50);
    },

    // Strip angle brackets from user-provided text.
    toText: function (value) {
      return String(value).replace(/[<>]/g, "").trim();
    }
  };
})();
